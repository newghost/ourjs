{
    "postdate"    : "int"
  , "reply"       : "textarea"
  , "poster"      : "string"
  , "nickname"    : "string"
  , "deleted"     : "bool"
}