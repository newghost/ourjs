{
    "_id"           : "id"
  , "username"      : "shown,string"
  , "password"      : "password"
  , "briefinfo"     : "string"
  , "company"       : "string"
  , "email"         : "shown,email"
  , "isAdmin"       : "shown,int"
  , "joinedTime"    : "int"
}